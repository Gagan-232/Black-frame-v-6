const express=require('express'),helmet=require('helmet'),rl=require('express-rate-limit'),session=require('express-session');
const Database=require('better-sqlite3'),bcrypt=require('bcryptjs'),multer=require('multer'),crypto=require('crypto'),fs=require('fs'),path=require('path'),{authenticator}=require('otplib');
const E=process.env,prod=E.NODE_ENV==='production';
if(!E.SESSION_SECRET||!E.DOWNLOAD_SECRET){console.error('Set SESSION_SECRET and DOWNLOAD_SECRET');process.exit(1)}
const db=new Database(path.join(E.DATA_DIR||'.','data.db'));db.pragma('journal_mode=WAL');
db.exec(`CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT);
CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY,email TEXT UNIQUE,hash TEXT,role TEXT DEFAULT 'owner',totp TEXT,totp_on INTEGER DEFAULT 0,ver INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS builds(id INTEGER PRIMARY KEY,version TEXT,file TEXT,size INTEGER,sha256 TEXT,platform TEXT,changelog TEXT,approved INTEGER DEFAULT 0,created INTEGER);
CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY,order_id TEXT UNIQUE,payment_id TEXT UNIQUE,amount INTEGER,status TEXT,token TEXT,created INTEGER);
CREATE TABLE IF NOT EXISTS ads(nonce TEXT PRIMARY KEY,done INTEGER DEFAULT 0,revenue REAL DEFAULT 0,created INTEGER);
CREATE TABLE IF NOT EXISTS grants(token TEXT PRIMARY KEY,kind TEXT,exp INTEGER,used INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS ad_slots(id INTEGER PRIMARY KEY,name TEXT,placement TEXT,provider TEXT DEFAULT 'adsense',unit TEXT DEFAULT '',w INTEGER DEFAULT 300,h INTEGER DEFAULT 250,maxw INTEGER DEFAULT 0,margin INTEGER DEFAULT 16,padding INTEGER DEFAULT 0,desktop INTEGER DEFAULT 1,mobile INTEGER DEFAULT 1,enabled INTEGER DEFAULT 0,bg TEXT DEFAULT '',border TEXT DEFAULT '',pos INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY,type TEXT,info TEXT,ip TEXT,t INTEGER);`);
try{db.exec('ALTER TABLE builds ADD COLUMN url TEXT')}catch{}
const mf=u=>{try{const x=new URL(String(u).trim());return x.protocol==='https:'&&(x.hostname==='mediafire.com'||x.hostname.endsWith('.mediafire.com'))?x.href.slice(0,500):''}catch{return ''}};
const D={title:'NIGHT SHIFT',studio:'BLACK FRAME STUDIO',btn_buy:'Buy Now',btn_ad:'Watch Ad & Download',btn_free:'Free Download',status:'coming_soon',price:59,ads_enabled:0,paid_enabled:0,free:0,tagline:'ENTER THE UNKNOWN.',sub:'Some places are better left unexplored.',story:'',features:[],screens:[],trailer:'',sysreq:'',announce:'',footer:'© BLACK FRAME STUDIO',dev:'BLACK FRAME STUDIO is an independent studio developing and publishing NIGHT SHIFT.',release:''};
const get=()=>{const o={...D};for(const r of db.prepare('SELECT * FROM settings').all())o[r.k]=JSON.parse(r.v);o.sections=normSec(o.sections);o.theme=normTheme(o.theme);return o};
const set=(k,v)=>db.prepare('INSERT INTO settings VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v').run(k,JSON.stringify(v));
const log=(type,info,req)=>db.prepare('INSERT INTO events(type,info,ip,t) VALUES(?,?,?,?)').run(String(type).slice(0,40),String(info||'').replace(/[\r\n]/g,' ').slice(0,200),req?.ip||'',Date.now());
if(E.ADMIN_EMAIL&&E.ADMIN_PASSWORD&&!db.prepare('SELECT 1 FROM admins').get()&&E.ADMIN_PASSWORD.length>=12)
 db.prepare('INSERT INTO admins(email,hash) VALUES(?,?)').run(E.ADMIN_EMAIL.toLowerCase(),bcrypt.hashSync(E.ADMIN_PASSWORD,12));
process.on('unhandledRejection',e=>console.error('unhandled',e&&e.message));process.on('uncaughtException',e=>console.error('uncaught',e&&e.message));
const app=express();app.set('trust proxy',1);
app.use(helmet({contentSecurityPolicy:{directives:{defaultSrc:["'self'"],scriptSrc:["'self'","'unsafe-inline'","https://pagead2.googlesyndication.com","https://checkout.razorpay.com"],styleSrc:["'self'","'unsafe-inline'"],imgSrc:["'self'","data:","https:"],frameSrc:["'self'","https://www.youtube-nocookie.com","https://googleads.g.doubleclick.net","https://tpc.googlesyndication.com","https://api.razorpay.com","https://checkout.razorpay.com"],connectSrc:["'self'","https://pagead2.googlesyndication.com","https://lumberjack.razorpay.com"]}}}));
// Webhook needs the raw body for signature verification
app.post('/api/pay/webhook',express.raw({type:'application/json'}),(req,res)=>{
 const sig=req.get('x-razorpay-signature')||'',want=crypto.createHmac('sha256',E.RAZORPAY_WEBHOOK_SECRET||'x').update(req.body).digest('hex');
 if(!E.RAZORPAY_WEBHOOK_SECRET||sig.length!==want.length||!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(want))){log('webhook_bad_sig','',req);return res.sendStatus(400)}
 const ev=JSON.parse(req.body),p=ev.payload?.payment?.entity;
 if(ev.event==='payment.captured'&&p){const row=db.prepare('SELECT * FROM purchases WHERE order_id=?').get(p.order_id);
  if(row&&row.status==='created'&&p.amount===row.amount){ // idempotent: only created->paid once; payment_id UNIQUE
   try{db.prepare("UPDATE purchases SET status='paid',payment_id=?,token=? WHERE id=?").run(p.id,crypto.randomBytes(24).toString('hex'),row.id);log('purchase',p.id)}catch{}}}
 res.sendStatus(200)});
app.use(express.json({limit:'100kb'}));app.use('/api',rl({windowMs:60e3,max:300,standardHeaders:true,legacyHeaders:false}));
app.use(session({name:'bf.sid',secret:E.SESSION_SECRET,resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:'strict',secure:prod,maxAge:2*3600e3}}));
app.use((req,res,next)=>{if(!req.session.csrf)req.session.csrf=crypto.randomBytes(16).toString('hex');
 if(!['GET','HEAD'].includes(req.method)&&req.path!=='/api/ads/ssv'&&req.get('x-csrf')!==req.session.csrf)return res.status(403).json({error:'csrf'});next()});
app.get('/api/csrf',(q,r)=>r.json({csrf:q.session.csrf}));
const admin=(q,r,n)=>{const a=q.session.aid&&db.prepare('SELECT ver FROM admins WHERE id=?').get(q.session.aid);a&&a.ver===q.session.ver?n():r.status(401).json({error:'auth'})};
// ---------- public
app.get('/api/public',(q,r)=>{const s=get(),b=db.prepare('SELECT version,size,platform,changelog,created,(url IS NOT NULL) ext FROM builds WHERE approved=1 ORDER BY id DESC LIMIT 5').all();
 if(!q.session.seen){q.session.seen=1;log('visit','',q)}
 const{ads_enabled,paid_enabled,...rest}=s;r.json({...rest,ads:!!ads_enabled&&!!E.AD_SSV_SECRET,paid:!!paid_enabled&&!!E.RAZORPAY_KEY_ID,builds:b,slots:pubSlots(),adsClient:adClient()})});
const grant=(kind,min=10)=>{const t=crypto.randomBytes(24).toString('hex');db.prepare('INSERT INTO grants VALUES(?,?,?,0)').run(t,kind,Date.now()+min*6e4);return t};
const open=s=>s.status==='available'||s.status==='free'||s.free;
app.post('/api/free',(q,r)=>{const s=get();if(!(s.status==='free'||s.free))return r.status(403).json({error:'not free'});r.json({token:grant('free')})});
// rewarded ads: provider calls /api/ads/ssv (server-to-server, signed) after a COMPLETED ad
app.post('/api/ads/start',rl({windowMs:6e4,max:10}),(q,r)=>{const s=get();if(!s.ads_enabled||!E.AD_SSV_SECRET||s.status!=='available')return r.status(403).json({error:'ads off'});
 const n=crypto.randomBytes(16).toString('hex');db.prepare('INSERT INTO ads(nonce,created) VALUES(?,?)').run(n,Date.now());r.json({nonce:n})});
app.get('/api/ads/ssv',(q,r)=>{const{nonce='',sig='',revenue='0'}=q.query,want=crypto.createHmac('sha256',E.AD_SSV_SECRET||'x').update(nonce+'|'+revenue).digest('hex');
 if(!E.AD_SSV_SECRET||sig.length!==want.length||!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(want)))return r.sendStatus(400);
 db.prepare('UPDATE ads SET done=1,revenue=? WHERE nonce=? AND done=0').run(Number(revenue)||0,nonce);r.sendStatus(200)});
app.get('/api/ads/status/:n',(q,r)=>{const a=db.prepare('SELECT * FROM ads WHERE nonce=?').get(q.params.n);if(!a||!a.done)return r.json({done:false});
 if(a.done===1){db.prepare('UPDATE ads SET done=2 WHERE nonce=?').run(a.nonce);return r.json({done:true,token:grant('ad')})}r.json({done:true,used:true})});
app.post('/api/pay/order',rl({windowMs:6e4,max:10}),async(q,r)=>{const s=get();if(!s.paid_enabled||!E.RAZORPAY_KEY_ID||s.status!=='available')return r.status(403).json({error:'payments off'});
 const amt=Math.round(s.price*100),res=await fetch('https://api.razorpay.com/v1/orders',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Basic '+Buffer.from(E.RAZORPAY_KEY_ID+':'+E.RAZORPAY_KEY_SECRET).toString('base64')},body:JSON.stringify({amount:amt,currency:'INR',receipt:'bf_'+Date.now()})});
 if(!res.ok)return r.status(502).json({error:'gateway'});const o=await res.json();db.prepare("INSERT INTO purchases(order_id,amount,status,created) VALUES(?,?,'created',?)").run(o.id,amt,Date.now());r.json({order_id:o.id,key:E.RAZORPAY_KEY_ID,amount:amt})});
app.get('/api/pay/status/:o',(q,r)=>{const p=db.prepare("SELECT token FROM purchases WHERE order_id=? AND status='paid'").get(q.params.o);r.json(p?{paid:true,token:p.token}:{paid:false})});
app.post('/api/pay/redeem',rl({windowMs:6e4,max:10}),(q,r)=>{const p=db.prepare("SELECT 1 FROM purchases WHERE token=? AND status='paid'").get(q.body.token||'');p?r.json({token:grant('paid')}):r.status(403).json({error:'invalid'})});
app.get('/api/download',(q,r)=>{const g=db.prepare('SELECT * FROM grants WHERE token=? AND exp>?').get(q.query.t||'',Date.now());
 const b=db.prepare('SELECT * FROM builds WHERE approved=1 ORDER BY id DESC').get();if(!g||!b||get().status==='temporarily_unavailable')return r.sendStatus(403);
 if(g.used>=3)return r.sendStatus(403);db.prepare('UPDATE grants SET used=used+1 WHERE token=?').run(g.token);log('download',g.kind,q);if(q.session.pid)db.prepare('INSERT INTO player_downloads(pid,version,t) VALUES(?,?,?)').run(q.session.pid,b.version,Date.now());
 if(b.url)return r.json({url:b.url}); // external (MediaFire) build: link is released only with a valid grant
 r.download(path.join(__dirname,'private',b.file),`NightShift-${b.version}${path.extname(b.file)}`)});
// ---------- admin auth
const lim=rl({windowMs:15*60e3,max:8,standardHeaders:true});
app.post('/api/admin/login',lim,(q,r)=>{const{email='',password='',code=''}=q.body,a=db.prepare('SELECT * FROM admins WHERE email=?').get(String(email).toLowerCase());
 const ok=a&&bcrypt.compareSync(String(password),a.hash)&&(!a.totp_on||authenticator.check(String(code),a.totp));
 if(!ok){log('login_fail',email,q);return r.status(401).json({error:'Invalid credentials'})}
 q.session.regenerate(()=>{q.session.aid=a.id;q.session.ver=a.ver;q.session.csrf=crypto.randomBytes(16).toString('hex');log('login_ok',email,q);r.json({csrf:q.session.csrf})})});
app.post('/api/admin/logout',(q,r)=>q.session.destroy(()=>r.json({ok:1})));
app.use('/api/admin',admin);
app.get('/api/admin/me',(q,r)=>r.json({ok:1,totp:!!db.prepare('SELECT totp_on t FROM admins WHERE id=?').get(q.session.aid).t}));
app.get('/api/admin/stats',(q,r)=>{const c=t=>db.prepare('SELECT COUNT(*) n FROM events WHERE type=?').get(t).n,pay=db.prepare("SELECT COALESCE(SUM(amount),0) s,COUNT(*) n FROM purchases WHERE status='paid'").get(),ad=db.prepare('SELECT COUNT(*) n,COALESCE(SUM(revenue),0) s FROM ads WHERE done>0').get();
 r.json({visitors:c('visit'),downloads:c('download'),purchases:pay.n,payRevenue:pay.s/100,adCompletions:ad.n,activeSlots:db.prepare('SELECT COUNT(*) n FROM ad_slots WHERE enabled=1').get().n,adRevenueReported:ad.s,total:pay.s/100+ad.s,recent:db.prepare('SELECT type,info,t FROM events ORDER BY id DESC LIMIT 15').all()})});
app.get('/api/admin/settings',(q,r)=>r.json({...get(),razorpay:!!E.RAZORPAY_KEY_ID,adsSecret:!!E.AD_SSV_SECRET}));
const ok=['contact_email','studio','btn_buy','btn_ad','btn_free','sections','theme','title','status','price','ads_enabled','paid_enabled','free','tagline','sub','story','features','screens','trailer','sysreq','announce','footer','dev','release'],st=['coming_soon','available','temporarily_unavailable','free'];
app.put('/api/admin/settings',(q,r)=>{const b=q.body;if(b.status&&!st.includes(b.status))return r.status(400).json({error:'status'});if('price' in b&&!(b.price>=0&&b.price<=100000))return r.status(400).json({error:'price'});
 for(const k of ok)if(k in b){let v=b[k];if(k==='contact_email'&&v&&!/^[^\s@<>"']{1,64}@[^\s@<>"']{1,190}\.[^\s@<>"']{2,}$/.test(String(v)))return r.status(400).json({error:'Invalid contact email'});if(k==='sections')v=normSec(v);if(k==='theme')v=normTheme(v);if(typeof v==='string')v=v.slice(0,5000);set(k,v)}log('settings','',q);r.json({ok:1})});
app.get('/api/admin/builds',(q,r)=>r.json(db.prepare('SELECT * FROM builds ORDER BY id DESC').all()));
const up=multer({storage:multer.diskStorage({destination:'private',filename:(q,f,cb)=>cb(null,crypto.randomBytes(16).toString('hex')+'.bin')}),limits:{fileSize:2*1024**3,files:1},
 fileFilter:(q,f,cb)=>cb(null,/\.(apk|aab|zip|exe|7z)$/i.test(f.originalname))});
app.post('/api/admin/builds',up.single('file'),(q,r)=>{if(!q.file&&q.body.url){const u=mf(q.body.url);if(!u)return r.status(400).json({error:'Link must be an https://www.mediafire.com/... URL'});
  db.prepare('INSERT INTO builds(version,file,size,sha256,platform,changelog,created,url) VALUES(?,?,?,?,?,?,?,?)').run(String(q.body.version||'0.0.0').slice(0,30),null,0,null,String(q.body.platform||'Android').slice(0,30),String(q.body.changelog||'').slice(0,3000),Date.now(),u);log('upload_link',q.body.version,q);return r.json({ok:1})}
 if(!q.file)return r.status(400).json({error:'Allowed: apk aab zip exe 7z'});
 const sig=Buffer.alloc(4),fd=fs.openSync(q.file.path,'r');fs.readSync(fd,sig,0,4,0);fs.closeSync(fd);const ext=path.extname(q.file.originalname).toLowerCase(),
  good=ext==='.7z'?sig.equals(Buffer.from([0x37,0x7a,0xbc,0xaf])):ext==='.exe'?sig.subarray(0,2).equals(Buffer.from('MZ')):sig.equals(Buffer.from([0x50,0x4b,3,4]));
 if(!good){fs.rmSync(q.file.path,{force:true});return r.status(400).json({error:'File content does not match its extension'})}
 const h=crypto.createHash('sha256');fs.createReadStream(q.file.path).on('data',d=>h.update(d)).on('end',()=>{
 // Not published until explicitly approved. Run a malware scan (e.g. ClamAV) before approving.
 db.prepare('INSERT INTO builds(version,file,size,sha256,platform,changelog,created) VALUES(?,?,?,?,?,?,?)').run(String(q.body.version||'0.0.0').slice(0,30),q.file.filename,q.file.size,h.digest('hex'),String(q.body.platform||'Android').slice(0,30),String(q.body.changelog||'').slice(0,3000),Date.now());log('upload',q.body.version,q);r.json({ok:1})})});
app.post('/api/admin/builds/:id/approve',(q,r)=>{db.prepare('UPDATE builds SET approved=? WHERE id=?').run(q.body.approved?1:0,q.params.id);log('approve',q.params.id+':'+q.body.approved,q);r.json({ok:1})});
app.delete('/api/admin/builds/:id',(q,r)=>{const b=db.prepare('SELECT file FROM builds WHERE id=?').get(q.params.id);if(b){if(b.file)fs.rmSync(path.join(__dirname,'private',b.file),{force:true});db.prepare('DELETE FROM builds WHERE id=?').run(q.params.id)}r.json({ok:1})});
app.post('/api/admin/password',(q,r)=>{const a=db.prepare('SELECT * FROM admins WHERE id=?').get(q.session.aid),n=String(q.body.new||'');
 if(!bcrypt.compareSync(String(q.body.old||''),a.hash)||n.length<12)return r.status(400).json({error:'Wrong current password or new one under 12 chars'});
 db.prepare('UPDATE admins SET hash=?,ver=ver+1 WHERE id=?').run(bcrypt.hashSync(n,12),a.id);log('pw_change','',q);q.session.destroy(()=>r.json({ok:1,relogin:1}))});
app.post('/api/admin/logout-all',(q,r)=>{db.prepare('UPDATE admins SET ver=ver+1').run();log('logout_all','',q);q.session.destroy(()=>r.json({ok:1}))});
app.post('/api/admin/2fa/setup',(q,r)=>{const s=authenticator.generateSecret(),a=db.prepare('SELECT email FROM admins WHERE id=?').get(q.session.aid);db.prepare('UPDATE admins SET totp=?,totp_on=0 WHERE id=?').run(s,q.session.aid);r.json({secret:s,uri:authenticator.keyuri(a.email,'BLACK FRAME STUDIO',s)})});
app.post('/api/admin/2fa/enable',(q,r)=>{const a=db.prepare('SELECT totp FROM admins WHERE id=?').get(q.session.aid);if(!a.totp||!authenticator.check(String(q.body.code),a.totp))return r.status(400).json({error:'bad code'});db.prepare('UPDATE admins SET totp_on=1 WHERE id=?').run(q.session.aid);r.json({ok:1})});
app.get('/api/admin/logs',(q,r)=>r.json(db.prepare("SELECT type,info,ip,t FROM events WHERE type LIKE 'login%' OR type IN('pw_change','logout_all','webhook_bad_sig','settings','upload','approve') ORDER BY id DESC LIMIT 60").all()));
// ---- CUSTOMIZATION START (sections, theme, ad slots)
const SEC=['hero','story','features','shots','trailer','download','dev'],FONTS=['impact','system','serif'];
const TD={primary:'#b0121b',bg:'#050505',surface:'#111111',text:'#d8d4cf',radius:0,spacing:90,font:'impact',motion:1};
const nn=(v,lo,hi,d)=>{v=Math.round(Number(v));return v>=lo&&v<=hi?v:d},hex=v=>/^#[0-9a-f]{6}$/i.test(v||'');
function normSec(a){a=Array.isArray(a)?a:[];const seen=new Set(),o=[];for(const x of a)if(x&&SEC.includes(x.key)&&!seen.has(x.key)){seen.add(x.key);o.push({key:x.key,enabled:(x.enabled===0||x.enabled===false)?0:1,title:String(x.title||'').slice(0,80),body:String(x.body||'').slice(0,500)})}
 for(const k of SEC)if(!seen.has(k))o.push({key:k,enabled:1,title:'',body:''});return o}
function normTheme(t){t=t&&typeof t==='object'?t:{};const o={...TD};for(const k of['primary','bg','surface','text'])if(hex(t[k]))o[k]=t[k];
 o.radius=nn(t.radius,0,24,0);o.spacing=nn(t.spacing,30,160,90);o.motion=nn(t.motion,0,1,1);if(FONTS.includes(t.font))o.font=t.font;return o}
const PL=['after:nav',...SEC.map(k=>'after:'+k),'inside:download','footer'];
function slotClean(b){const unit=String(b.unit||'').trim(),prov=PROV.includes(b.provider)?b.provider:'adsense';if(!unitOk(prov,unit))return{err:prov==='adsterra'?'Adsterra key must be 32 hex characters':'AdSense unit ID must be 6-20 digits'};
 if(!PL.includes(b.placement))return{err:'Bad placement'};
 return{v:[String(b.name||'Slot').slice(0,60),b.placement,prov,unit,nn(b.w,50,1200,300),nn(b.h,20,1200,250),nn(b.maxw,0,1600,0),nn(b.margin,0,120,16),nn(b.padding,0,60,0),b.desktop?1:0,b.mobile?1:0,b.enabled?1:0,hex(b.bg)?b.bg:'',hex(b.border)?b.border:'']}}
const adClient=()=>/^ca-pub-\d{6,20}$/.test(E.ADSENSE_CLIENT||'')?E.ADSENSE_CLIENT:'';
// A slot goes public only when enabled AND it has a unit ID AND the publisher ID is configured. Nothing is ever simulated.
function pubSlots(){return db.prepare("SELECT id,placement,provider,unit,w,h,maxw,margin,padding,desktop,mobile,bg,border FROM ad_slots WHERE enabled=1 AND unit!='' ORDER BY pos,id").all().filter(x=>x.provider==='adsterra'||adClient())}
const SC='name,placement,provider,unit,w,h,maxw,margin,padding,desktop,mobile,enabled,bg,border';
app.get('/api/admin/slots',(q,r)=>r.json({client:!!adClient(),placements:PL,slots:db.prepare('SELECT * FROM ad_slots ORDER BY pos,id').all().map(x=>({...x,live:!!(x.enabled&&x.unit&&(x.provider==='adsterra'||adClient()))}))}));
app.post('/api/admin/slots',(q,r)=>{const c=slotClean(q.body);if(c.err)return r.status(400).json({error:c.err});
 const p=db.prepare('SELECT COALESCE(MAX(pos),-1)+1 n FROM ad_slots').get().n;
 const id=db.prepare(`INSERT INTO ad_slots(${SC},pos) VALUES(${SC.split(',').map(()=>'?').join(',')},?)`).run(...c.v,p).lastInsertRowid;log('slot_add',id,q);r.json({ok:1,id})});
app.put('/api/admin/slots/:id',(q,r)=>{const c=slotClean(q.body);if(c.err)return r.status(400).json({error:c.err});
 db.prepare(`UPDATE ad_slots SET ${SC.split(',').map(k=>k+'=?').join(',')} WHERE id=?`).run(...c.v,q.params.id);log('slot_edit',q.params.id,q);r.json({ok:1})});
app.delete('/api/admin/slots/:id',(q,r)=>{db.prepare('DELETE FROM ad_slots WHERE id=?').run(q.params.id);log('slot_del',q.params.id,q);r.json({ok:1})});
app.post('/api/admin/slots/:id/move',(q,r)=>{const a=db.prepare('SELECT id FROM ad_slots ORDER BY pos,id').all().map(x=>x.id),i=a.indexOf(+q.params.id),j=i+(q.body.dir<0?-1:1);
 if(i>=0&&j>=0&&j<a.length){[a[i],a[j]]=[a[j],a[i]];const u=db.prepare('UPDATE ad_slots SET pos=? WHERE id=?');db.transaction(()=>a.forEach((id,n)=>u.run(n,id)))()}r.json({ok:1})});
const PROV=['adsense','adsterra'];
const unitOk=(p,u)=>!u||(p==='adsterra'?/^[a-f0-9]{32}$/.test(u):/^\d{6,20}$/.test(u));
// Adsterra units render in a sandboxed same-site frame (/ad-frame/:id) with its own CSP, so the network script can't touch site cookies or other slots.
const adFrameHtml=s=>`<!doctype html><html><head><meta charset="utf-8"><style>html,body{margin:0;background:transparent;overflow:hidden}</style></head><body><script>atOptions=${JSON.stringify({key:s.unit,format:'iframe',height:s.h,width:s.w,params:{}})}</script><script src="https://bicea.org/22/${s.unit}"></script></body></html>`;
app.get('/ad-frame/:id',(q,r)=>{const s=db.prepare("SELECT unit,w,h FROM ad_slots WHERE id=? AND enabled=1 AND provider='adsterra' AND unit!=''").get(+q.params.id||0);if(!s||!unitOk('adsterra',s.unit))return r.sendStatus(404);
 r.set('Content-Security-Policy',"default-src 'none'; script-src https: 'unsafe-inline' 'unsafe-eval'; img-src https: data:; style-src 'unsafe-inline' https:; frame-src https:; connect-src https:; frame-ancestors 'self'");r.set('Cache-Control','no-store');r.type('html').send(adFrameHtml(s))});
// One-time seed of the two Adsterra banners you supplied (flag stored so deleting them later sticks)
if(!db.prepare("SELECT 1 FROM settings WHERE k='seed_adsterra_v1'").get()){const ins=db.prepare("INSERT INTO ad_slots(name,placement,provider,unit,w,h,margin,desktop,mobile,enabled,pos) VALUES(?,?,'adsterra',?,?,?,16,1,1,1,?)");
 ins.run('Adsterra 300x250','after:hero','70b9082466d21a06b2725c4dde6096f8',300,250,100);ins.run('Adsterra 320x50','after:nav','73e97d246347004d51fe2f71725d6e8c',320,50,101);
 db.prepare("INSERT INTO settings(k,v) VALUES('seed_adsterra_v1','1')").run()}
// ---- CUSTOMIZATION END
require('./pages')(app,db,{get,log,admin});
app.use(express.static('public',{extensions:['html']}));
app.get('/admin',(q,r)=>r.sendFile(path.join(__dirname,'public','admin.html')));
app.use((e,q,r,n)=>{console.error(e.message);r.status(500).json({error:'server'})});
app.listen(E.PORT||3000,()=>console.log('BLACK FRAME on :'+(E.PORT||3000)));
