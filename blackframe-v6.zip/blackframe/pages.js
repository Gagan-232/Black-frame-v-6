// Player accounts + server-routed pages. Mounted from server.js. Player auth (session.pid) is separate from admin auth (session.aid).
const rl=require('express-rate-limit'),bcrypt=require('bcryptjs'),crypto=require('crypto');
module.exports=(app,db,{get,log,admin})=>{
db.exec(`CREATE TABLE IF NOT EXISTS players(id INTEGER PRIMARY KEY,email TEXT UNIQUE NOT NULL,name TEXT DEFAULT '',hash TEXT NOT NULL,status TEXT DEFAULT 'active',ver INTEGER DEFAULT 0,del_req INTEGER DEFAULT 0,created INTEGER);
CREATE TABLE IF NOT EXISTS player_downloads(id INTEGER PRIMARY KEY,pid INTEGER NOT NULL REFERENCES players(id),version TEXT,t INTEGER);
CREATE INDEX IF NOT EXISTS pd_p ON player_downloads(pid,t);`);
const em=v=>String(v||'').trim().toLowerCase(),DUMMY=bcrypt.hashSync('x',12),
 lim=rl({windowMs:15*60e3,max:20,standardHeaders:true,legacyHeaders:false,message:{error:'Too many attempts. Try again later.'}});
const start=(q,r,p,remember)=>q.session.regenerate(e=>{if(e)return r.status(500).json({error:'session'});q.session.pid=p.id;q.session.pver=p.ver;q.session.csrf=crypto.randomBytes(16).toString('hex');if(remember)q.session.cookie.maxAge=30*864e5;r.json({ok:1,csrf:q.session.csrf})});
const P=(q,r,n)=>{const p=q.session.pid&&db.prepare('SELECT * FROM players WHERE id=?').get(q.session.pid);
 if(p&&p.status==='active'&&p.ver===q.session.pver){q.player=p;r.set('Cache-Control','no-store');return n()}
 q.originalUrl.startsWith('/api')?r.status(401).json({error:'login'}):r.redirect('/login')};
const fails=new Map();setInterval(()=>{const n=Date.now();for(const[k,v]of fails)if(v.t<n)fails.delete(k)},6e4).unref();
const bad=(r,m,c=400)=>r.status(c).json({error:m});
app.post('/api/auth/register',lim,async(q,r)=>{const b=q.body||{},e=em(b.email),pw=String(b.password||''),nm=String(b.name||'').trim().slice(0,40);
 if(e.length>254||!/^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,}$/.test(e))return bad(r,'Enter a valid email');
 if(pw.length<10||pw.length>128)return bad(r,'Password must be 10-128 characters');
 if(pw!==b.confirm)return bad(r,'Passwords do not match');if(!b.terms)return bad(r,'Please accept the terms and privacy policy');
 const dup='Could not create an account with these details';
 if(db.prepare('SELECT 1 FROM players WHERE email=?').get(e))return bad(r,dup,409);
 const h=await bcrypt.hash(pw,12);let id;try{id=Number(db.prepare('INSERT INTO players(email,name,hash,created) VALUES(?,?,?,?)').run(e,nm,h,Date.now()).lastInsertRowid)}catch{return bad(r,dup,409)}
 log('player_register',String(id),q);start(q,r,{id,ver:0})});
app.post('/api/auth/login',lim,async(q,r)=>{const b=q.body||{},fk=em(b.email),f=fails.get(fk);if(f&&f.n>=10&&f.t>Date.now())return bad(r,'Too many attempts. Try again later.',429);const p=db.prepare('SELECT * FROM players WHERE email=?').get(em(b.email)),ok=await bcrypt.compare(String(b.password||'').slice(0,128),p?p.hash:DUMMY);
 if(!p||!ok||p.status!=='active'){log('player_login_fail','',q);fails.set(fk,{n:(f&&f.t>Date.now()?f.n:0)+1,t:Date.now()+15*6e4});return bad(r,'Incorrect email or password',401)}
 fails.delete(fk);
 log('player_login_ok',String(p.id),q);start(q,r,p,!!b.remember)});
app.get('/api/auth/me',P,(q,r)=>{const p=q.player;r.json({email:p.email,name:p.name,created:p.created,delRequested:!!p.del_req})});
app.post('/api/auth/logout',(q,r)=>q.session.destroy(()=>r.json({ok:1})));
app.post('/api/auth/password',P,lim,async(q,r)=>{const n=String(q.body.new||'');
 if(!await bcrypt.compare(String(q.body.old||'').slice(0,128),q.player.hash)||n.length<10||n.length>128)return bad(r,'Wrong current password, or the new one is not 10-128 characters');
 db.prepare('UPDATE players SET hash=?,ver=ver+1 WHERE id=?').run(await bcrypt.hash(n,12),q.player.id);log('player_pw_change',String(q.player.id),q);
 start(q,r,{id:q.player.id,ver:q.player.ver+1})}); // other sessions are revoked by the version bump
app.post('/api/auth/logout-all',P,(q,r)=>{db.prepare('UPDATE players SET ver=ver+1 WHERE id=?').run(q.player.id);log('player_logout_all',String(q.player.id),q);q.session.destroy(()=>r.json({ok:1}))});
app.post('/api/account/name',P,(q,r)=>{db.prepare('UPDATE players SET name=? WHERE id=?').run(String(q.body.name||'').trim().slice(0,40),q.player.id);r.json({ok:1})});
app.post('/api/account/delete-request',P,lim,async(q,r)=>{if(!await bcrypt.compare(String(q.body.password||'').slice(0,128),q.player.hash))return bad(r,'Wrong password');
 db.prepare('UPDATE players SET del_req=1 WHERE id=?').run(q.player.id);log('player_delete_req',String(q.player.id),q);r.json({ok:1})});
app.get('/api/account/downloads',P,(q,r)=>r.json(db.prepare('SELECT version,t FROM player_downloads WHERE pid=? ORDER BY t DESC LIMIT 100').all(q.player.id))); // own rows only
// admin: player management (the /api/admin middleware already requires an admin session)
app.get('/api/admin/players',(q,r)=>r.json({players:db.prepare("SELECT p.id,p.email,p.name,p.status,p.created,p.del_req,(SELECT COUNT(*) FROM player_downloads d WHERE d.pid=p.id) downloads FROM players p WHERE p.email LIKE ? ESCAPE '\\' ORDER BY p.id DESC LIMIT 200").all('%'+String(q.query.q||'').replace(/[\\%_]/g,'\\$&').toLowerCase()+'%')}));
app.post('/api/admin/players/:id/status',(q,r)=>{const s=q.body.status;if(!['active','suspended'].includes(s))return bad(r,'status');
 db.prepare('UPDATE players SET status=?,ver=ver+1 WHERE id=?').run(s,q.params.id);log('player_'+s,q.params.id,q);r.json({ok:1})});
// ---- pages
const base=q=>process.env.PUBLIC_URL?process.env.PUBLIC_URL.replace(/\/+$/,''):(/^[a-z0-9.-]+(:\d+)?$/i.test(q.get('host')||'')?q.protocol+'://'+q.get('host'):'');
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const shell=(path,title,desc,body,priv)=>(q,r)=>{const s=get(),t=esc(title+' | '+(s.studio||'BLACK FRAME STUDIO')),url=base(q)+path;
 r.set('Cache-Control',priv?'no-store':'public,max-age=300');
 r.send(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${t}</title><meta name="description" content="${esc(desc)}"><meta property="og:title" content="${t}"><meta property="og:description" content="${esc(desc)}"><meta property="og:type" content="website">${priv?'<meta name="robots" content="noindex">':`<link rel="canonical" href="${esc(url)}">`}<link rel="stylesheet" href="/site.css"><link rel="stylesheet" href="/motion.css"><noscript><style>.rv{opacity:1!important;transform:none!important}</style></noscript></head><body data-page="${esc(path)}"><a class="skip" href="#main">Skip to content</a><header class="top"><a class="logo" href="/">BLACK <b>FRAME</b></a><button class="burger" aria-label="Menu" aria-expanded="false">☰</button><nav id="nav"><a href="/">Home</a><a href="/games">Games</a><a href="/about">About</a><a href="/contact">Contact</a><span id="acct"><a href="/login">Login</a></span></nav></header><main id="main" class="page">${body}</main><footer class="foot">© ${esc(s.studio||'BLACK FRAME STUDIO')} · <a href="/about">About</a> · <a href="/contact">Contact</a></footer><div id="toast" role="status" aria-live="polite"></div><script src="/app.js" defer></script><script src="/motion.js" defer></script></body></html>`)};
const F=(id,l,t='text',x='')=>`<label for="${id}">${l}</label><input id="${id}" name="${id}" type="${t}" ${x}>`;
const pages=[
['/login','Login','Sign in to your player account.',`<section class="auth rv"><h1>Login</h1><form id="f-login">${F('email','Email','email','autocomplete="email" required')}${F('password','Password','password','autocomplete="current-password" required')}<label class="ck"><input type="checkbox" id="show"> Show password</label><label class="ck"><input type="checkbox" id="remember"> Remember me for 30 days</label><button class="btn">Login</button></form><p class="m">No account? <a href="/register">Register</a>. Password reset by email is not available yet.</p></section>`],
['/register','Register','Create a player account.',`<section class="auth rv"><h1>Create account</h1><form id="f-reg">${F('email','Email','email','autocomplete="email" required')}${F('name','Display name (optional)','text','maxlength="40"')}${F('password','Password (10+ characters)','password','autocomplete="new-password" required minlength="10"')}<div class="meter"><i id="meter"></i></div>${F('confirm','Confirm password','password','autocomplete="new-password" required')}<label class="ck"><input type="checkbox" id="terms" required> I agree to the terms and privacy policy</label><button class="btn">Create account</button></form><p class="m">Already registered? <a href="/login">Login</a></p></section>`],
['/games','Games','Games by BLACK FRAME STUDIO.',`<h1 class="rv">Games</h1><div class="grid"><a class="card gc rv" href="/games/night-shift"><span class="tag" id="g-status">…</span><h2 id="g-title">NIGHT SHIFT</h2><p id="g-tag"></p></a></div>`],
['/games/night-shift','NIGHT SHIFT','NIGHT SHIFT, a horror game by BLACK FRAME STUDIO.',`<section class="hero2"><span class="tag" id="n-status"></span><h1 id="n-title">NIGHT SHIFT</h1><p id="n-tag" class="lead"></p><a class="btn" href="/#download">Download options</a></section><section class="rv"><h2>Story</h2><div id="n-story"></div></section><section class="rv"><h2>Features</h2><ul id="n-feat"></ul></section><section class="rv"><h2>System requirements</h2><div id="n-req"></div></section><section class="rv"><h2>Announcement</h2><div id="n-ann"></div></section><section class="rv"><h2>Version history</h2><div id="n-ver"></div></section>`],
['/about','About','About BLACK FRAME STUDIO.',`<h1 class="rv">About</h1><p class="rv" id="a-dev"></p>`],
['/contact','Contact','Contact BLACK FRAME STUDIO.',`<h1 class="rv">Contact</h1><p class="rv" id="c-info">Loading…</p>`],
];
for(const[p,t,d,b]of pages)app.get(p,shell(p,t,d,b,['/login','/register'].includes(p)?1:0));
const priv=[
['/dashboard','Dashboard',`<h1 class="rv">Welcome, <span id="d-name"></span></h1><div class="grid"><div class="card rv"><h3>Account</h3><p id="d-email"></p><p class="m" id="d-since"></p><a href="/profile">Profile</a></div><div class="card rv"><h3>Your games</h3><p><a href="/games/night-shift">NIGHT SHIFT</a></p></div><div class="card rv"><h3>Recent downloads</h3><div id="d-dl"></div><a href="/downloads">All downloads</a></div></div><button class="btn g" id="logout">Logout</button>`],
['/profile','Profile',`<h1 class="rv">Profile</h1><section class="card rv"><form id="f-name">${F('name','Display name','text','maxlength="40"')}<button class="btn">Save</button></form></section><section class="card rv"><h3>Change password</h3><form id="f-pw">${F('old','Current password','password','autocomplete="current-password" required')}${F('new','New password (10+ characters)','password','autocomplete="new-password" required minlength="10"')}<button class="btn">Change</button></form></section><section class="card rv"><h3>Sessions</h3><p class="m">Sign out every device, including this one.</p><button class="btn g" id="all">Logout everywhere</button></section><section class="card rv"><h3>Delete account</h3><p class="m" id="del-state">Submits a request; an administrator completes it.</p><form id="f-del">${F('password','Confirm password','password','required')}<button class="btn g">Request deletion</button></form></section>`],
['/downloads','Downloads',`<h1 class="rv">Downloads</h1><p class="m">Download history on this account. To download, use the options on the <a href="/games/night-shift">NIGHT SHIFT</a> page.</p><div id="dl-list" class="rv"></div>`],
];
for(const[p,t,b]of priv)app.get(p,P,shell(p,t,'Private page.',b,1));
app.get('/robots.txt',(q,r)=>r.type('text').send(`User-agent: *\nDisallow: /admin\nDisallow: /api/\nDisallow: /dashboard\nDisallow: /profile\nDisallow: /downloads\nSitemap: ${base(q)}/sitemap.xml\n`));
app.get('/sitemap.xml',(q,r)=>r.type('xml').send(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${['/','/games','/games/night-shift','/about','/contact'].map(p=>`<url><loc>${base(q)}${p}</loc></url>`).join('')}</urlset>`));
};
