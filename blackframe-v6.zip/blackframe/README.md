# BLACK FRAME
Full-stack site: Node/Express + SQLite, vanilla cinematic front end, mobile-first admin at /admin.
## Run
npm install && cp .env.example .env (fill in) && export $(cat .env|xargs) && npm start
First start seeds the admin from ADMIN_EMAIL / ADMIN_PASSWORD (12+ chars). Remove the password from .env afterwards, and enable 2FA in Admin > Security.
Deploy behind HTTPS (Render, Railway, Fly, VPS). Mobile-only workflow: push to GitHub, deploy on Render.
## Needs YOUR credentials / work
- Razorpay: key id/secret + webhook (event payment.captured) -> https://YOURDOMAIN/api/pay/webhook with RAZORPAY_WEBHOOK_SECRET. Payments stay off without keys.
- Rewarded ads: wire your ad network SDK in index.html `watch()`. Configure the network's server-side verification callback to GET /api/ads/ssv?nonce=..&revenue=..&sig=HMAC_SHA256(AD_SSV_SECRET, nonce|revenue). Some networks (AdMob) use their own signature scheme: adapt that one function. Revenue shown is only what the callback reports; confirm with your ad network's dashboard.
- Uploaded builds are private and need manual approval. Run ClamAV (or similar) before approving.
## Honest limits
- Database is SQLite (single file, back it up). Swapping to PostgreSQL means replacing better-sqlite3 calls.
- Sessions use the in-memory store: use a persistent store for multi-instance deployments.
- Frontend is vanilla JS, not React/Framer Motion, to keep it light on phones. Image upload for screenshots is via URL; builds use private storage.
- Not security-audited: review before taking real money.

## Phase 2 additions (BLACK FRAME STUDIO / NIGHT SHIFT)
- Studio = BLACK FRAME STUDIO (nav, loader, footer). Game = NIGHT SHIFT (hero, downloads, titles). If you saved a title earlier, re-save it in Admin > Settings.
- Admin > Sections: show/hide, retitle, add description, reorder.
- Admin > Appearance: colors, radius, spacing, heading font, effects on/off, live preview, reset.
- Admin > Ads: add/edit/delete/move AdSense slots (placement, unit ID, size, max width, margin, padding, desktop/mobile, colors). Set ADSENSE_CLIENT=ca-pub-... in .env. A slot renders publicly only if enabled + unit ID + ADSENSE_CLIENT are set. Preview boxes are layout only.
- Fixed: CSP blocked Razorpay checkout; now allowed. Button labels editable.
## Not built yet
Player accounts (the ZIP had none), Razorpay already present but untested, ad analytics from provider APIs, image/video upload, roles, migrations, backups guide.
## Untested
No dependencies could be installed in my environment, so the server was never started. Only syntax checks and the validation helpers were run. Run `npm install && npm start` and test before use.
## MediaFire link mode
Admin > Game: paste a https://www.mediafire.com/... link instead of uploading. Nothing is stored on your server. The link is not in the public page; it is returned only with a valid one-time grant (after a verified ad, payment, or free), which expires in 10 minutes. Once shown, a player can copy or share it: that cannot be prevented. Automatic upload to MediaFire is not built (needs MediaFire API credentials and I could not verify it).

## Phase 3: pages and player accounts
Routes (server-rendered, work on direct open/refresh): / /login /register /games /games/night-shift /about /contact; private (redirect to /login): /dashboard /profile /downloads. /admin unchanged. Also /robots.txt, /sitemap.xml.
API: POST /api/auth/register|login|logout|password|logout-all, GET /api/auth/me, POST /api/account/name|delete-request, GET /api/account/downloads (own rows only). Admin: GET /api/admin/players?q=, POST /api/admin/players/:id/status. All POSTs need the x-csrf header from /api/csrf.
New tables (created if missing, nothing altered or deleted): players, player_downloads. Player sessions (session.pid) are separate from admin sessions (session.aid).
Railway: set DATA_DIR to your volume mount so data.db persists. Sessions use the default in-memory store: they are lost on restart and not suitable for multiple instances.
## Still not built
Password reset and email verification (no email provider), admin roles beyond owner, game CRUD for multiple games, charts, re-auth for sensitive admin actions, Adsterra manager, GSAP-level motion (CSS-only here), account activity beyond downloads, malware scanning, automated tests. Nothing was run: dependencies could not be installed and I have no access to your repo or Railway.
## Motion layer (public/motion.css + motion.js, no libraries)
Page wipe transitions, scroll progress bar, cursor flashlight (desktop), film grain + vignette, ember particle canvas (fewer on mobile, paused when tab hidden), 3D card tilt with glare, magnetic buttons, periodic glitch on logo/titles, heading scramble on reveal, hero parallax. All disabled under prefers-reduced-motion. Untested in a browser; tune/remove effects in motion.js if any feel heavy.
## Adsterra banners
Added as Ad Manager slots (provider "adsterra"), seeded once at first start: 300x250 below the hero (key 70b9...), 320x50 below the nav (key 73e9...). Each renders in a sandboxed iframe from /ad-frame/:id (own CSP, no top-level navigation, no cookie access). Edit placement/size/visibility or delete them in Admin > Ads. They appear only on the home page, never on admin, login or account pages. Revenue/impressions are in your Adsterra dashboard; none are shown here.
## Security review (static) and smoke tests
Review found and fixed: Host-header injection into canonical/sitemap (set PUBLIC_URL), uploads checked by extension only (now magic bytes too), unhandled async errors could crash Node (global handlers added), no global API limiter (300/min/IP added), per-account login lockout (10 fails/15 min), log injection (values trimmed), unvalidated public contact email, redeem endpoint unlimited, content hidden if JS blocked.
Known remaining: CSP still allows 'unsafe-inline' scripts; in-memory sessions; paid token is reusable by whoever holds it and /api/pay/status/:order returns it to anyone with the order id; register reveals whether an email exists (409) and its timing differs; no malware scanning; no email verification/reset.
Run `BASE=http://localhost:3000 node tests/security-smoke.js` against a running server (needs a fresh DB or throwaway data; it creates two test players).
