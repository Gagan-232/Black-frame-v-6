const $=s=>document.querySelector(s),pg=document.body.dataset.page;let CS='';
const api=async(u,m='GET',b)=>{if(m!=='GET'&&!CS)CS=(await(await fetch('/api/csrf')).json()).csrf;
 const r=await fetch(u,{method:m,headers:{'Content-Type':'application/json','x-csrf':CS},body:b?JSON.stringify(b):undefined}),j=await r.json().catch(()=>({}));if(j.csrf)CS=j.csrf;return{...j,ok:r.ok,status:r.status}};
function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('show');clearTimeout(t._t);t._t=setTimeout(()=>t.classList.remove('show'),3500)}
const T=(s,v)=>{const e=$(s);if(e)e.textContent=v??''},fmt=t=>new Date(t).toLocaleString();
function paras(s,v){const e=$(s);if(!e)return;e.replaceChildren();String(v||'').split(/\n+/).filter(Boolean).forEach(x=>{const p=document.createElement('p');p.textContent=x;e.append(p)});if(!e.children.length)e.innerHTML='<p class="m">Not published yet.</p>'}
const b=$('.burger');b.onclick=()=>{const o=$('#nav').classList.toggle('open');b.setAttribute('aria-expanded',o)};
document.querySelectorAll('nav a').forEach(a=>{if(a.pathname===pg)a.setAttribute('aria-current','page')});
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('on');io.unobserve(e.target)}}),{threshold:.1});document.querySelectorAll('.rv').forEach(e=>io.observe(e));
api('/api/auth/me').then(m=>{if(m.ok&&m.email){$('#acct').innerHTML='<a href="/dashboard">Dashboard</a>'}});
const form=(id,fn)=>{const f=$(id);if(f)f.onsubmit=async e=>{e.preventDefault();const btn=f.querySelector('button');btn.disabled=true;try{await fn(f)}finally{btn.disabled=false}}};
form('#f-login',async()=>{const r=await api('/api/auth/login','POST',{email:$('#email').value,password:$('#password').value,remember:$('#remember').checked});r.ok?location.href='/dashboard':toast(r.error||'Login failed')});
form('#f-reg',async()=>{const r=await api('/api/auth/register','POST',{email:$('#email').value,name:$('#name').value,password:$('#password').value,confirm:$('#confirm').value,terms:$('#terms').checked});r.ok?location.href='/dashboard':toast(r.error||'Failed')});
const sh=$('#show');if(sh)sh.onchange=()=>document.querySelectorAll('input[type=password]').forEach(i=>i.type=sh.checked?'text':'password');
const pw=$('#password'),mt=$('#meter');if(pw&&mt)pw.oninput=()=>{const v=pw.value;mt.style.width=Math.min(100,(v.length>=10)*30+(/[A-Z]/.test(v)&&/[a-z]/.test(v))*20+/\d/.test(v)*20+/[^\w\s]/.test(v)*20+(v.length>=14)*10)+'%'};
form('#f-name',async()=>{const r=await api('/api/account/name','POST',{name:$('#name').value});toast(r.ok?'Saved':'Failed')});
form('#f-pw',async()=>{const r=await api('/api/auth/password','POST',{old:$('#old').value,new:$('#new').value});toast(r.ok?'Password changed; other devices signed out':r.error);if(r.ok)$('#f-pw').reset()});
form('#f-del',async()=>{if(!confirm('Request account deletion?'))return;const r=await api('/api/account/delete-request','POST',{password:$('#password').value});toast(r.ok?'Request submitted':r.error)});
const lo=$('#logout');if(lo)lo.onclick=async()=>{await api('/api/auth/logout','POST');location.href='/'};
const all=$('#all');if(all)all.onclick=async()=>{if(confirm('Sign out everywhere?')){await api('/api/auth/logout-all','POST');location.href='/login'}};
const rows=(el,L)=>{el.replaceChildren();if(!L.length){el.innerHTML='<p class="m">No downloads yet.</p>';return}const t=document.createElement('table');t.innerHTML='<tr><th>Version</th><th>Date</th></tr>';L.forEach(x=>{const r=t.insertRow();r.insertCell().textContent=x.version;r.insertCell().textContent=fmt(x.t)});el.append(t)};
(async()=>{
 if(pg==='/dashboard'||pg==='/profile'){const m=await api('/api/auth/me');T('#d-name',m.name||m.email);T('#d-email',m.email);T('#d-since',m.created?'Member since '+fmt(m.created):'');const n=$('#name');if(n)n.value=m.name||'';if(m.delRequested)T('#del-state','Deletion requested; pending administrator action.')}
 if(pg==='/dashboard'){const l=await api('/api/account/downloads');rows($('#d-dl'),(l.length?l:[]).slice(0,5))}
 if(pg==='/downloads'){rows($('#dl-list'),await api('/api/account/downloads'))}
 if(['/games','/games/night-shift','/about','/contact'].includes(pg)){const s=await(await fetch('/api/public')).json(),st=(s.status||'').replace(/_/g,' ');
  T('#g-status',st);T('#g-title',s.title);T('#g-tag',s.tagline);T('#n-status',st);T('#n-title',s.title);T('#n-tag',s.sub||s.tagline);
  paras('#n-story',s.story);paras('#n-req',s.sysreq);paras('#n-ann',s.announce);paras('#a-dev',s.dev);
  const f=$('#n-feat');if(f){(s.features||[]).forEach(x=>{const li=document.createElement('li');li.textContent=typeof x==='string'?x:[x.title,x.text||x.desc].filter(Boolean).join(': ');f.append(li)});if(!f.children.length)f.innerHTML='<li class="m">Not published yet.</li>'}
  const v=$('#n-ver');if(v){(s.builds||[]).forEach(x=>{const d=document.createElement('div');d.className='card';d.textContent=x.version+' · '+x.platform+' · '+new Date(x.created).toLocaleDateString()+(x.changelog?' — '+x.changelog:'');v.append(d)});if(!v.children.length)v.innerHTML='<p class="m">No public builds yet.</p>'}
  const c=$('#c-info');if(c){c.textContent='';if(s.contact_email){const a=document.createElement('a');a.href='mailto:'+s.contact_email;a.textContent=s.contact_email;c.append('Email us: ',a)}else c.textContent='Contact details have not been published yet.'}}
})();
