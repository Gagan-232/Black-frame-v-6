(()=>{const RM=matchMedia('(prefers-reduced-motion:reduce)').matches,FINE=matchMedia('(hover:hover) and (pointer:fine)').matches,$$=s=>[...document.querySelectorAll(s)],mk=(c,p=document.body)=>{const d=document.createElement('div');d.className=c;p.append(d);return d};
// page transition (works even with reduced motion: instant)
const wipe=mk('mx-wipe');addEventListener('pageshow',()=>wipe.classList.remove('go'));
document.addEventListener('click',e=>{const a=e.target.closest('a');if(!a||RM||e.defaultPrevented||e.button||e.metaKey||e.ctrlKey||e.shiftKey||a.target||a.origin!==location.origin||(a.pathname===location.pathname&&a.hash)||a.hasAttribute('download'))return;
 e.preventDefault();wipe.classList.add('go');setTimeout(()=>location.href=a.href,340)});
if(RM)return;
// scroll progress + hero parallax (one rAF-throttled scroll handler)
const bar=mk('mx-bar');let tick=0;const sc=()=>{tick=0;const h=document.documentElement,y=scrollY,m=h.scrollHeight-innerHeight;bar.style.transform=`scaleX(${m>0?y/m:0})`;$$('.hero2').forEach(e=>e.style.transform=`translateY(${Math.min(y,600)*.25}px)`)};
addEventListener('scroll',()=>{tick||(tick=requestAnimationFrame(sc))},{passive:true});sc();
mk('mx-vig');if(!$$('.grain').length)mk('mx-grain');
// flashlight (desktop only)
if(FINE){const fl=mk('mx-fl');let p=0,x=0,y=0;addEventListener('pointermove',e=>{x=e.clientX;y=e.clientY;fl.classList.add('on');p||(p=requestAnimationFrame(()=>{p=0;fl.style.setProperty('--fx',x+'px');fl.style.setProperty('--fy',y+'px')}))},{passive:true});document.addEventListener('mouseleave',()=>fl.classList.remove('on'))}
// 3D tilt + glare on cards, magnetic buttons
if(FINE){document.addEventListener('pointermove',e=>{const c=e.target.closest&&e.target.closest('.card'),b=e.target.closest&&e.target.closest('.btn');
 if(c&&!c.closest('form')){const r=c.getBoundingClientRect(),px=(e.clientX-r.left)/r.width,py=(e.clientY-r.top)/r.height;c.style.transform=`perspective(800px) rotateX(${(.5-py)*7}deg) rotateY(${(px-.5)*9}deg) translateY(-4px)`;c.style.setProperty('--gx',px*100+'%');c.style.setProperty('--gy',py*100+'%')}
 if(b){const r=b.getBoundingClientRect();b.style.transform=`translate(${(e.clientX-r.left-r.width/2)*.12}px,${(e.clientY-r.top-r.height/2)*.2}px)`}},{passive:true});
 document.addEventListener('pointerout',e=>{const t=e.target.closest&&e.target.closest('.card,.btn');if(t&&!t.contains(e.relatedTarget))t.style.transform=''})}
// heading scramble on first reveal
const CH='█▓▒░/\\#%&@*',scr=el=>{const f=el.textContent;if(!f||el.children.length||f.length>40||el._s)return;el._s=1;let i=0;const t=setInterval(()=>{el.textContent=[...f].map((c,j)=>c===' '||j<i?c:CH[Math.random()*CH.length|0]).join('');if((i+=.7)>=f.length){el.textContent=f;clearInterval(t)}},30)};
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){scr(e.target);io.unobserve(e.target)}}),{threshold:.4});setTimeout(()=>$$('h1,h2').forEach(h=>io.observe(h)),400);
// periodic glitch on logo/wordmark/h1 (only while tab visible)
const gl=el=>{if(!el||document.hidden)return;el.classList.add('glitch');el.dataset.text=el.textContent;el.classList.add('g-on');setTimeout(()=>el.classList.remove('g-on'),480)};
const targets=()=>$$('.logo,.hero .wm,.hero2 h1,.page>h1');setInterval(()=>{const t=targets();gl(t[Math.random()*t.length|0])},5500);
document.addEventListener('pointerover',e=>{const t=e.target.closest&&e.target.closest('.logo');t&&gl(t)});
// ember canvas (skipped if the page already has its own canvas)
if(!$$('canvas').length){const cv=document.createElement('canvas');cv.className='mx-cv';document.body.prepend(cv);const c=cv.getContext('2d'),dpr=Math.min(devicePixelRatio||1,1.5),N=innerWidth<700?26:70;let W,H,mx=0,my=0,run=1;
 const size=()=>{W=cv.width=innerWidth*dpr;H=cv.height=innerHeight*dpr};size();addEventListener('resize',size);
 const P=Array.from({length:N},()=>({x:Math.random()*W,y:Math.random()*H,r:(.6+Math.random()*1.8)*dpr,v:(.15+Math.random()*.5)*dpr,s:Math.random()*6.28,d:.3+Math.random()*.7}));
 addEventListener('pointermove',e=>{mx=e.clientX/innerWidth-.5;my=e.clientY/innerHeight-.5},{passive:true});
 document.addEventListener('visibilitychange',()=>{run=!document.hidden;run&&requestAnimationFrame(f)});
 function f(t){if(!run)return;c.clearRect(0,0,W,H);for(const p of P){p.y-=p.v;p.s+=.01;p.x+=Math.sin(p.s)*.4*dpr;if(p.y<-10){p.y=H+10;p.x=Math.random()*W}
  const a=(.25+.35*Math.sin(t/700+p.s))*p.d,X=p.x+mx*30*p.d*dpr,Y=p.y+my*20*p.d*dpr;c.beginPath();c.arc(X,Y,p.r,0,6.283);c.fillStyle=`rgba(255,${70+p.d*60|0},50,${Math.max(a,.05)})`;c.shadowColor='#ff3b47';c.shadowBlur=6*dpr;c.fill()}requestAnimationFrame(f)}
 requestAnimationFrame(f)}
})();
