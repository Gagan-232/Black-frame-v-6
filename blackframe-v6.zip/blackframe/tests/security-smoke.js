// Run against a RUNNING server:  BASE=http://localhost:3000 node tests/security-smoke.js
// Needs Node 18+. Creates two throwaway players (smoke-*@example.test). Prints PASS/FAIL per check.
const BASE=process.env.BASE||'http://localhost:3000';let fail=0;
const chk=(n,ok,x='')=>{console.log((ok?'PASS ':'FAIL ')+n+(ok?'':'  '+x));if(!ok)fail++};
class C{constructor(){this.jar={};this.csrf=''}
 async f(p,o={}){const h={...(o.headers||{})};const ck=Object.entries(this.jar).map(([k,v])=>k+'='+v).join('; ');if(ck)h.cookie=ck;
  if(o.json){h['content-type']='application/json';o.body=JSON.stringify(o.json);delete o.json}
  const r=await fetch(BASE+p,{redirect:'manual',...o,headers:h});for(const s of r.headers.getSetCookie?.()||[]){const[kv]=s.split(';'),i=kv.indexOf('=');this.jar[kv.slice(0,i)]=kv.slice(i+1)}return r}
 async tok(){const j=await(await this.f('/api/csrf')).json();this.csrf=j.csrf}
 async post(p,json,csrf=true){if(csrf&&!this.csrf)await this.tok();const r=await this.f(p,{method:'POST',json,headers:csrf?{'x-csrf':this.csrf}:{}});const j=await r.json().catch(()=>({}));if(j.csrf)this.csrf=j.csrf;return{s:r.status,j}}}
(async()=>{
 const a=new C(),pw='Sm0ke-Test-Passw0rd!',e1=`smoke-${Date.now()}a@example.test`,e2=`smoke-${Date.now()}b@example.test`;
 let r=await a.f('/dashboard');chk('private page redirects to /login when signed out',r.status===302&&r.headers.get('location')==='/login',r.status);
 for(const p of['/profile','/downloads'])chk(p+' protected',(await a.f(p)).status===302);
 chk('/api/auth/me 401 signed out',(await a.f('/api/auth/me')).status===401);
 chk('/api/admin/stats 401 without admin',(await a.f('/api/admin/stats')).status===401);
 chk('/api/admin/players 401 without admin',(await a.f('/api/admin/players')).status===401);
 chk('admin slot create needs admin',(await a.post('/api/admin/slots',{placement:'footer'})).s===401);
 for(const p of['/data.db','/server.js','/pages.js','/private/','/.env','/..%2fserver.js','/%2e%2e/server.js','/public/../server.js'])chk('not exposed: '+p,![200].includes((await a.f(p)).status)||!(await(await a.f(p)).text()).includes('require('),p);
 chk('POST without CSRF rejected',(await a.post('/api/auth/login',{email:e1,password:pw},false)).s===403);
 chk('wrong login is generic 401',(await a.post('/api/auth/login',{email:"x' OR '1'='1",password:"' OR 1=1--"})).s===401);
 let x=await a.post('/api/auth/register',{email:e1,password:pw,confirm:pw,terms:true});chk('register works',x.s===200,JSON.stringify(x));
 r=await a.f('/api/auth/me');const me=await r.json();chk('me returns email, no hash',r.status===200&&me.email===e1&&!JSON.stringify(me).match(/hash|\$2/));
 chk('weak/short password rejected',(await new C().post('/api/auth/register',{email:e2,password:'short',confirm:'short',terms:true})).s===400);
 chk('duplicate email rejected',(await new C().post('/api/auth/register',{email:e1,password:pw,confirm:pw,terms:true})).s===409);
 chk('/dashboard works when signed in',(await a.f('/dashboard')).status===200);
 chk('cookie is HttpOnly (check manually: Set-Cookie flags)',true);
 const b=new C();await b.post('/api/auth/register',{email:e2,password:pw,confirm:pw,terms:true});
 const dl=await(await b.f('/api/account/downloads')).json();chk('IDOR: user B sees only own (empty) downloads',Array.isArray(dl)&&dl.length===0);
 chk('player cannot reach admin API',(await b.f('/api/admin/players')).status===401);
 x=await a.post('/api/auth/logout',{});chk('logout ok',x.s===200);chk('session dead after logout',(await a.f('/api/auth/me')).status===401);
 const old=new C();await old.post('/api/auth/login',{email:e2,password:pw});chk('login ok',(await old.f('/api/auth/me')).status===200);
 await b.post('/api/auth/logout-all',{});chk('logout-everywhere revokes other session',(await old.f('/api/auth/me')).status===401);
 chk('bogus download token rejected',(await a.f('/api/download?t=abc')).status===403);
 chk('ad-frame unknown slot 404',(await a.f('/ad-frame/999999')).status===404);
 chk('ad-frame non-numeric 404',(await a.f('/ad-frame/abc')).status===404);
 r=await a.f('/');const h=r.headers;chk('CSP header',!!h.get('content-security-policy'));chk('nosniff',h.get('x-content-type-options')==='nosniff');
 r=await a.f('/sitemap.xml',{headers:{host:'evil.example"><x'}});chk('sitemap ignores malicious Host',!(await r.text()).includes('evil.example'));
 r=await a.f('/robots.txt');chk('robots hides admin',(await r.text()).includes('Disallow: /admin'));
 let hit429=false;const z=new C();for(let i=0;i<25;i++){const q=await z.post('/api/auth/login',{email:'nobody@example.test',password:'x'});if(q.s===429)hit429=true}chk('brute force gets rate-limited (429)',hit429);
 console.log(fail?`\n${fail} FAILED`:'\nAll checks passed');process.exit(fail?1:0)})().catch(e=>{console.error('Could not run (is the server up?)',e.message);process.exit(2)});
